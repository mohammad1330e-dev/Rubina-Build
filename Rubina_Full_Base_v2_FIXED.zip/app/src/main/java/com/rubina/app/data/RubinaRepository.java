package com.rubina.app.data;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.rubina.app.model.*;

public class RubinaRepository {
    public void saveUser(User user, AsyncCallback<User> cb) {
        Backendless.Persistence.of(User.class).save(user, cb);
    }
    public void sendMessage(Message message, AsyncCallback<Message> cb) {
        Backendless.Persistence.of(Message.class).save(message, cb);
    }
    public void saveReport(Report report, AsyncCallback<Report> cb) {
        Backendless.Persistence.of(Report.class).save(report, cb);
    }
    public void saveGroup(Group group, AsyncCallback<Group> cb) {
        Backendless.Persistence.of(Group.class).save(group, cb);
    }
    public void saveChannel(Channel channel, AsyncCallback<Channel> cb) {
        Backendless.Persistence.of(Channel.class).save(channel, cb);
    }
}
