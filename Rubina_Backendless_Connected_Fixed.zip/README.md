# Rubina - Online Build
نسخه اصلاح‌شده و توسعه‌یافته پروژه روبینا برای Build آنلاین.

## خروجی پیشنهادی
`app/build/outputs/apk/release/app-release.apk`

## Build
از Android Gradle Plugin 8.5.2 و Gradle 8.7 استفاده می‌شود.

این نسخه یک رابط کاربری واقعی‌تر شامل خانه، پیام‌ها، تماس‌ها، روبینا AI، پروفایل، حالت تاریک و آیکن برنامه دارد. قابلیت‌های آنلاین واقعی (سرور، حساب کاربری، تماس واقعی و AI متصل به API) در این نسخه شبیه‌سازی شده‌اند و برای فعال شدن به Backend/API نیاز دارند.


## Backendless
The Android project now includes the Backendless Android SDK and initializes Backendless at app startup using BackendlessConfig.
