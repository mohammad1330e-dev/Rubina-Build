package com.rubina.app.model;
public class Group {
    public String objectId, name, description, ownerId, photoUrl;
    public int memberCount;
}
