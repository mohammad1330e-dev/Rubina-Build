package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class GroupActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("گروه‌ها");
  content.addView(card("👥 گروه دوستان\n۱۲۸ عضو"));
  content.addView(card("🎮 گیمرهای روبینا\n۵۴۲ عضو"));
  content.addView(action("ایجاد گروه",v->toast("ایجاد گروه آماده اتصال به سرور است.")));
  content.addView(action("جستجوی گروه",v->toast("جستجوی گروه")));
 }
}
