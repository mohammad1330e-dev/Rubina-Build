package com.rubina.app;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.*;
public class ChatActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("پیام‌های مستقیم");
  content.addView(card("گفت‌وگو با کاربر نمونه\nآخرین پیام  ✓✓"));
  content.addView(card("گروه دوستان\nپیام جدید  ✓✓"));
  EditText input=new EditText(this); input.setHint("پیام خود را بنویسید...");
  content.addView(input);
  content.addView(action("ارسال پیام",v->{ if(input.getText().length()>0){toast("پیام ارسال شد  ✓✓"); input.setText("");}}));
 }
}
