package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class RegisterActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("ثبت‌نام");
  for(String h:new String[]{"نام نمایشی","نام کاربری","ایمیل","رمز عبور"}){ EditText e=new EditText(this); e.setHint(h); content.addView(e); }
  content.addView(action("ایجاد حساب",v->toast("اطلاعات ثبت‌نام برای ارسال به سرور آماده است.")));
 }
}
