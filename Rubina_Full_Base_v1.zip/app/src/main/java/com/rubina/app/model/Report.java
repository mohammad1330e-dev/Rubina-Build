package com.rubina.app.model;
public class Report {
    public String objectId, reporterId, targetId, reason, details, status, createdAt;
}
