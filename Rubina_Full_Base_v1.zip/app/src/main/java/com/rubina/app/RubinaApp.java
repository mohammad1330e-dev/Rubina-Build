package com.rubina.app;

import android.app.Application;
import com.backendless.Backendless;

public class RubinaApp extends Application {
    private boolean connected;
    @Override public void onCreate() {
        super.onCreate();
        try {
            Backendless.initApp(getApplicationContext(),
                    BackendlessConfig.APPLICATION_ID,
                    BackendlessConfig.ANDROID_API_KEY);
            connected = true;
        } catch (Exception e) {
            connected = false;
        }
    }
    public boolean isConnected() { return connected; }
}
