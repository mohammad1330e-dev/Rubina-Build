package com.rubina.app.model;
public class User {
    public String objectId, username, displayName, avatarUrl, role;
    public boolean premium, blocked;
}
