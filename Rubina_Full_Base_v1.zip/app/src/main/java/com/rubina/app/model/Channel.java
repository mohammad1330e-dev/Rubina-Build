package com.rubina.app.model;
public class Channel {
    public String objectId, name, description, ownerId, photoUrl;
    public boolean verified;
}
