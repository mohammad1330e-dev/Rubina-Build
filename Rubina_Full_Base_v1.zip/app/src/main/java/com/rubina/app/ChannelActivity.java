package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class ChannelActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("کانال‌ها");
  content.addView(card("📢 روبینا نیوز\nکانال خبری"));
  content.addView(card("🎬 فیلم و سریال\nانتشار محتوای کانال"));
  content.addView(action("ایجاد کانال",v->toast("ایجاد کانال")));
  content.addView(action("ارسال پست / فیلم",v->toast("ارسال محتوا به کانال")));
  content.addView(action("جستجوی کانال",v->toast("جستجوی کانال")));
 }
}
