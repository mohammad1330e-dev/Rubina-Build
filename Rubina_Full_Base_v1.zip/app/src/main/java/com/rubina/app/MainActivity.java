package com.rubina.app;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends BaseActivity {
    TextView connection;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        page("روبینا");
        connection = card("🔄  اتصال...");
        content.addView(connection);
        ((RubinaApp)getApplication()).isConnected();
        connection.setText("🟢  متصل شد");
        EditText search = new EditText(this);
        search.setHint("جستجو در کاربران، گروه‌ها و کانال‌ها");
        content.addView(search, new LinearLayout.LayoutParams(-1,60));
        content.addView(card("👥 گروه‌ها"));
        content.addView(action("گروه‌های روبینا", v -> go(GroupActivity.class)));
        content.addView(card("📢 کانال‌ها"));
        content.addView(action("کانال‌های روبینا", v -> go(ChannelActivity.class)));
        content.addView(card("🎬 فیلم و سریال"));
        content.addView(action("ورود به بخش فیلم و سریال", v -> go(MediaActivity.class)));
        content.addView(card("⭐ روبینا پرمیوم"));
        content.addView(action("امکانات پرمیوم و بازی‌ها", v -> go(PremiumActivity.class)));
        content.addView(card("⚙ مدیریت و گزارش"));
        content.addView(action("گزارش تخلف", v -> go(ReportActivity.class)));
        content.addView(action("پنل مدیریت", v -> go(AdminPanelActivity.class)));
        content.addView(card("💬 پیام‌ها"));
        content.addView(action("پیام‌های مستقیم", v -> go(ChatActivity.class)));
        content.addView(action("👤 پروفایل", v -> go(ProfileActivity.class)));
        content.addView(action("ورود / ثبت‌نام", v -> go(LoginActivity.class)));
    }
}
