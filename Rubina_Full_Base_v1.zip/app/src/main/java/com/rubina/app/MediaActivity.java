package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class MediaActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("فیلم و سریال");
  content.addView(card("🎬 فیلم‌ها"));
  content.addView(card("📺 سریال‌ها"));
  content.addView(card("⭐ جدیدترین محتوا"));
  content.addView(action("جستجوی فیلم و سریال",v->toast("جستجوی محتوا")));
  content.addView(action("ارسال فیلم برای کانال",v->toast("آپلود رسانه پس از اتصال Storage فعال می‌شود.")));
 }
}
