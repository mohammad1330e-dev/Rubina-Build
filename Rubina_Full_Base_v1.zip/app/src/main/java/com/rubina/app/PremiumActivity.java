package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class PremiumActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("روبینا پرمیوم");
  content.addView(card("⭐ روبینا پرمیوم\nامکانات ویژه و نامحدود"));
  content.addView(card("🎮 بازی‌ها"));
  content.addView(action("مافیا",v->toast("اتاق مافیا آماده اتصال چندنفره است.")));
  content.addView(action("سنگ کاغذ قیچی",v->toast("بازی سنگ کاغذ قیچی")));
  content.addView(action("بازی‌های بیشتر",v->toast("بخش بازی‌ها قابل توسعه است.")));
  content.addView(action("فعال‌سازی پرمیوم",v->toast("پرداخت و اشتراک باید در سرور تنظیم شود.")));
 }
}
