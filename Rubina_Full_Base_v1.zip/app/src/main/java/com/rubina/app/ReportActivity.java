package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class ReportActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("گزارش تخلف");
  EditText target=new EditText(this); target.setHint("کاربر، گروه یا کانال"); content.addView(target);
  EditText reason=new EditText(this); reason.setHint("دلیل گزارش"); content.addView(reason);
  EditText details=new EditText(this); details.setHint("توضیحات بیشتر"); content.addView(details);
  content.addView(action("ارسال گزارش",v->toast("گزارش ثبت شد و برای بررسی مدیریت ارسال می‌شود.")));
 }
}
