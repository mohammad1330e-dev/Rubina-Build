package com.rubina.app.model;
public class Message {
    public String objectId, senderId, chatId, text, mediaUrl, createdAt;
    public boolean delivered, read;
}
