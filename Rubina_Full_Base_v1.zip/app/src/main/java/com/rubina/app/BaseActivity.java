package com.rubina.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import android.view.View;

public class BaseActivity extends Activity {
    protected LinearLayout root, content;
    protected int purple = Color.rgb(108,74,182);
    protected TextView title(String s) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(23); v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setTextColor(Color.rgb(39,35,45)); v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(18,8,18,8);
        return v;
    }
    protected TextView card(String s) {
        TextView v = title(s); v.setTextSize(16);
        GradientDrawable g = new GradientDrawable(); g.setColor(Color.rgb(241,238,247)); g.setCornerRadius(28);
        v.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 76); p.setMargins(5,6,5,6); v.setLayoutParams(p);
        return v;
    }
    protected Button action(String s, View.OnClickListener l) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(l);
        return b;
    }
    protected void page(String heading) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(250,249,252));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,10,12,24);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        content.addView(title(heading), new LinearLayout.LayoutParams(-1,66));
        setContentView(root);
    }
    protected void go(Class<?> c) { startActivity(new Intent(this,c)); }
    protected void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
