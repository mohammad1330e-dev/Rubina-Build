package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class LoginActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("ورود به روبینا");
  EditText user=new EditText(this); user.setHint("نام کاربری یا ایمیل"); content.addView(user);
  EditText pass=new EditText(this); pass.setHint("رمز عبور"); pass.setInputType(129); content.addView(pass);
  content.addView(action("ورود",v->toast("درخواست ورود آماده ارسال به سرور است.")));
  content.addView(action("ساخت حساب جدید",v->go(RegisterActivity.class)));
 }
}
