package com.rubina.app.model;
public class Premium {
    public String userId, plan, expiresAt;
    public boolean active, unlimited;
}
