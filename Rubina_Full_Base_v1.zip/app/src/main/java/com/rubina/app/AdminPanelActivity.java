package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class AdminPanelActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("پنل مدیریت");
  content.addView(card("🛡 پنل ادمین"));
  content.addView(action("گزارش‌های تخلف",v->go(ReportActivity.class)));
  content.addView(action("مدیریت کاربران",v->toast("مدیریت کاربران")));
  content.addView(action("مدیریت گروه‌ها و کانال‌ها",v->toast("مدیریت محتوا")));
  content.addView(action("پیام مستقیم به مالک",v->toast("پیام به مالک؛ شناسه، شماره و پروفایل مالک در رابط ادمین نمایش داده نمی‌شود.")));
  content.addView(card("👑 پنل مالک"));
  content.addView(action("گزارش‌های فوری تخلف",v->toast("اعلان تخلف برای مالک")));
  content.addView(action("مدیریت ادمین‌ها",v->toast("مدیریت نقش‌ها")));
 }
}
