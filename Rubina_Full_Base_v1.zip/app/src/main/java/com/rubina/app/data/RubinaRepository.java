package com.rubina.app.data;

import com.backendless.Backendless;
import com.backendless.persistence.DataQueryBuilder;
import java.util.List;
import com.rubina.app.model.*;

public class RubinaRepository {
    public void saveUser(User user, com.backendless.callbacks.AsyncCallback<User> cb) {
        Backendless.Persistence.of(User.class).save(user, cb);
    }
    public void sendMessage(Message message, com.backendless.callbacks.AsyncCallback<Message> cb) {
        Backendless.Persistence.of(Message.class).save(message, cb);
    }
    public void saveReport(Report report, com.backendless.callbacks.AsyncCallback<Report> cb) {
        Backendless.Persistence.of(Report.class).save(report, cb);
    }
    public void saveGroup(Group group, com.backendless.callbacks.AsyncCallback<Group> cb) {
        Backendless.Persistence.of(Group.class).save(group, cb);
    }
    public void saveChannel(Channel channel, com.backendless.callbacks.AsyncCallback<Channel> cb) {
        Backendless.Persistence.of(Channel.class).save(channel, cb);
    }
}
