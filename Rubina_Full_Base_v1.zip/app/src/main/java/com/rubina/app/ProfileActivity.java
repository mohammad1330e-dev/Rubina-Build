package com.rubina.app;
import android.os.Bundle;
import android.widget.*;
public class ProfileActivity extends BaseActivity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); page("پروفایل");
  content.addView(card("👤 کاربر روبینا\n@rubina_user"));
  content.addView(action("ویرایش پروفایل",v->toast("ویرایش پروفایل")));
  content.addView(action("ساخت / تغییر نام کاربری",v->toast("نام کاربری باید یکتا باشد.")));
  content.addView(action("تنظیمات و حریم خصوصی",v->toast("تنظیمات")));
 }
}
